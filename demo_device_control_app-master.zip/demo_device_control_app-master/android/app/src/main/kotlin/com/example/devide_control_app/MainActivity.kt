package com.example.devide_control_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
