
import 'package:flutter/material.dart';
import 'package:device_control_app/bar_graph/bar_graph.dart';
import 'package:device_control_app/line_chart/line_chart.dart';
import 'package:device_control_app/pie_chart/pie_chart.dart';

class HomeTabScreen extends StatelessWidget {
  final List<double> deviceSummary;

  const HomeTabScreen({super.key, required this.deviceSummary});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child:  Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          height: 300,
          child: BarGraph(
            deviceSummary: deviceSummary,
          ),
        ),
        SizedBox( 
          height: 200,
           child: LineChartSample(), 
        ),
        SizedBox( height: 200, child: PieChartSample(),) // Thêm PieChartSample 
      ],
    ),
    );
  }
}