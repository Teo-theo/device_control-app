import 'package:flutter/material.dart';

class HumidityScreen extends StatelessWidget {
  const HumidityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Độ ẩm')),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.water_drop, size: 100, color: Colors.blue),
            SizedBox(height: 20),
            Text('Độ ẩm hiện tại: 65%', style: TextStyle(fontSize: 24)),
          ],
        ),
      ),
    );
  }
}
