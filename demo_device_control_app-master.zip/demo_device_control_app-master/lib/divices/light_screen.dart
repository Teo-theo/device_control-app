import 'package:flutter/material.dart';

class LightScreen extends StatelessWidget {
  const LightScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ánh sáng')),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.lightbulb, size: 100, color: Colors.yellow),
            SizedBox(height: 20),
            Text('Độ sáng hiện tại: 500 Lux', style: TextStyle(fontSize: 24)),
          ],
        ),
      ),
    );
  }
}
