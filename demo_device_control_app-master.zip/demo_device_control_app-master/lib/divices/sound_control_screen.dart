import 'package:flutter/material.dart';

class SoundControlScreen extends StatelessWidget {
  const SoundControlScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Âm thanh')),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.volume_up, size: 100, color: Colors.green),
            SizedBox(height: 20),
            Text('Âm lượng hiện tại: 70%', style: TextStyle(fontSize: 24)),
          ],
        ),
      ),
    );
  }
}
