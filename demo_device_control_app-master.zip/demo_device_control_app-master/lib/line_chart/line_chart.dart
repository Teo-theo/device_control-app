import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class LineChartSample extends StatelessWidget {
  final List<FlSpot> tempData = [
    FlSpot(0, 20),
    FlSpot(1, 25),
    FlSpot(2, 23),
    FlSpot(3, 27),
    FlSpot(4, 24),
  ];

  final List<FlSpot> humidityData = [
    FlSpot(0, 65),
    FlSpot(1, 60),
    FlSpot(2, 62),
    FlSpot(3, 63),
    FlSpot(4, 64),
  ];

  final List<FlSpot> lightData = [
    FlSpot(0, 50),
    FlSpot(1, 55),
    FlSpot(2, 40),
    FlSpot(3, 60),
    FlSpot(4, 70),
  ];

  final List<FlSpot> soundData = [
    FlSpot(0, 30),
    FlSpot(1, 35),
    FlSpot(2, 32),
    FlSpot(3, 34),
    FlSpot(4, 31),
  ];

  final List<FlSpot> infraredData = [
    FlSpot(0, 5),
    FlSpot(1, 6),
    FlSpot(2, 4),
    FlSpot(3, 5),
    FlSpot(4, 6),
  ];

  @override
  Widget build(BuildContext context) {
    return LineChart(
      LineChartData(
        gridData: FlGridData(show: true),
        titlesData: FlTitlesData(show: true),
        borderData: FlBorderData(
          show: true,
          border: Border.all(color: Colors.black, width: 1),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: tempData,
            isCurved: true,
            color: Colors.red,
            barWidth: 2,
            isStrokeCapRound: true,
            dotData: FlDotData(show: true),
            belowBarData: BarAreaData(show: false),
          ),
          LineChartBarData(
            spots: humidityData,
            isCurved: true,
            color: Colors.blue,
            barWidth: 2,
            isStrokeCapRound: true,
            dotData: FlDotData(show: true),
            belowBarData: BarAreaData(show: false),
          ),
          LineChartBarData(
            spots: lightData,
            isCurved: true,
            color: Colors.yellow,
            barWidth: 2,
            isStrokeCapRound: true,
            dotData: FlDotData(show: true),
            belowBarData: BarAreaData(show: false),
          ),
          LineChartBarData(
            spots: soundData,
            isCurved: true,
            color: Colors.green,
            barWidth: 2,
            isStrokeCapRound: true,
            dotData: FlDotData(show: true),
            belowBarData: BarAreaData(show: false),
          ),
          LineChartBarData(
            spots: infraredData,
            isCurved: true,
            color: Colors.purple,
            barWidth: 2,
            isStrokeCapRound: true,
            dotData: FlDotData(show: true),
            belowBarData: BarAreaData(show: false),
          ),
        ],
      ),
    );
  }
}
